--[[
	main.lua
		Sets up the configuration panels specifics for Combuctor
--]]

local CONFIG, Config = ...
Config.addon = 'Combuctor'
Config.displayRowHeight = 35
Config.tabs = true