-- Death Knight

Raven.runeSpells = {
	["Army of the Dead"] = { count = 3, id = 42650 },
	["Blooddrinker"] = { count = 1, id = 206931 },
	["Chains of Ice"] = { count = 1, id = 45524 },
	["Clawing Shadows"] = { count = 1, id = 207311 },
	["Control Undead"] = { count = 1, id = 111673 },
	["Death and Decay"] = { count = 1, id = 43265 },
	["Death Gate"] = { count = 1, id = 50977 },
	["Death's Caress"] = { count = 1, id = 195292 },
	["Defile"] = { count = 1, id = 152280 },
	["Epidemic"] = { count = 1, id = 207317 },
	["Festering Strike"] = { count = 2, id = 197147 },
	["Frostscythe"] = { count = 1, id = 207230 },
	["Glacial Advance"] = { count = 1, id = 194913 },
	["Heart Strike"] = { count = 1, id = 206930 },
	["Howling Blast"] = { count = 1, id = 49184 },
	["Marrowrend"] = { count = 2, id = 195182 },
	["Obliterate"] = { count = 2, id = 49020 },
	["Path of Frost"] = { count = 1, id = 3714 },
	["Remorseless Winter"] = { count = 1, id = 196770 },
	["Rune Tap"] = { count = 1, id = 194679 },
	["Scourge Strike"] = { count = 1, id = 55090 },
	["Soul Reaper"] = { count = 1, id = 130736 },
}

Raven.classConditions.DEATHKNIGHT = {
}
